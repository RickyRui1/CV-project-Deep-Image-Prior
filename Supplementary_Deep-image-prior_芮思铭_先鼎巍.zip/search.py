import torch
import random
from copy import deepcopy
import numpy as np

class NASOptimizer:
    """
    Neural Architectural Search:
    it does not optimize over the parameters within the model, instead, 
    it optimize over the structure of the model. In this case, it modifies the
    skipmodel's channels of each layer.
    """
    def __init__(self, 
                 model_class, # SkipModel
                 input_channels,
                 criterion,
                 device,
                 img_size=(512, 512),
                 population_size=5,
                 num_generations=5,
                 mutation_rate=0.6,):
        self.model_class = model_class
        self.input_channels = input_channels
        self.criterion = criterion
        self.device = device
        self.img_size = img_size
        self.population_size = population_size
        self.num_generations = num_generations
        self.mutation_rate = mutation_rate
        self.best_architecture = None
        self.best_score = float('inf')
        self.possible_channels = [16, 32, 64, 128]
        self.depth = 5  
        
    def validate(self, architecture):
        """
        validates if the given skipmodel is feasible
        """
        try:
            channels_down = architecture['channels_down']
            channels_up = architecture['channels_up']
            channels_skip = architecture['channels_skip']
            
            # checks beforehand

            if not (len(channels_down) == len(channels_up) == len(channels_skip) == self.depth):
                return False , "Channel lists have length different to depth"
            for channels in [channels_down, channels_up, channels_skip]:
                if not all(ch in self.possible_channels for ch in channels):
                    return False , "Invalid channel numbers detected"
            h, w = self.img_size
            min_size = 2 ** (self.depth - 1)
            if h < min_size or w < min_size:
                return False , f"Image size must be at least {min_size}x{min_size} for depth {self.depth}"
            if h % (2 ** (self.depth - 1)) != 0 or w % (2 ** (self.depth - 1)) != 0:
                return False , "Image dimensions must be divisible by 2^(depth-1)"
            
            # try model and test forward pass
            model = self.model_class(
                in_channels=self.input_channels,
                out_channels=3,
                channels_down=channels_down,
                channels_up=channels_up,
                channels_skip=channels_skip
            )
            test_input = torch.randn(1, self.input_channels, h, w)
            output = model(test_input)
            if output.shape != (1, 3, h, w):
                return False, f"Output shape {output.shape} doesn't match expected shape {(1, 3, h, w)}"
            
            return True, "Valid architecture"
            
        except Exception as e:
            return False, str(e)
    
    def random_generate(self):
        """generate a valid random model"""
        max_attempts = 50
        for _ in range(max_attempts):
            # random choice
            channels_down = sorted([random.choice(self.possible_channels) for _ in range(self.depth)],reverse=True)
            channels_up = channels_down[::-1]
            channels_skip = [random.choice([ch for ch in self.possible_channels if ch <= down_ch])for down_ch in channels_down]
            architecture = {
                'channels_down': channels_down,
                'channels_up': channels_up,
                'channels_skip': channels_skip
            }
            is_valid, _ = self.validate(architecture)
            if is_valid:
                return architecture
    
    def mutate(self, architecture):
        """mutate model while ensuring validity"""
        max_attempts = 20
        
        for _ in range(max_attempts):
            new_arch = deepcopy(architecture)
            if random.random() < self.mutation_rate:
                # mutate encoder
                idx = random.randint(0, self.depth-1)
                new_ch = random.choice(self.possible_channels)
                new_arch['channels_down'][idx] = new_ch
                new_arch['channels_up'][-(idx+1)] = new_ch
            
            if random.random() < self.mutation_rate:
                # mutate skip channels
                idx = random.randint(0, self.depth-1)
                valid_choices = [ch for ch in self.possible_channels if ch <= new_arch['channels_down'][idx]]
                if valid_choices:
                    new_arch['channels_skip'][idx] = random.choice(valid_choices)
            
            is_valid, _ = self.validate(new_arch)
            if is_valid:
                return new_arch
        return architecture

    def evaluate(self, architecture, eval_steps=20):
        """Evaluate a model"""
        try:
            model = self.model_class(
                in_channels=self.input_channels,
                out_channels=3,
                **architecture
            ).to(self.device)
            
            optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
            total_loss = 0
            h, w = self.img_size
            
            for _ in range(eval_steps):
                optimizer.zero_grad()
                noise = torch.randn(1, self.input_channels, h, w).to(self.device)
                output = model(noise)
                loss = self.criterion(output * self.mask_tensor, self.img_tensor * self.mask_tensor)
                loss.backward()
                optimizer.step()
                total_loss += loss.item()
                
            return total_loss / eval_steps
            
        except Exception as e:
            return float('inf')

    def search(self, mask_tensor, img_tensor):
        """Run architecture search with provided mask and image tensors"""
        self.mask_tensor = mask_tensor.to(self.device)
        self.img_tensor = img_tensor.to(self.device)
        # initialize population
        start_gen = 0
        population = []
        while len(population) < self.population_size:
            try:
                arch = self.random_generate()
                population.append(arch)
            except Exception as e:
                #print(f"Error generating architecture: {e}")
                continue
        
        # evolve
        for generation in range(start_gen, self.num_generations):
            scores = []
            valid_architectures = []
            for arch in population:
                score = self.evaluate(arch)
                if score != float('inf'):
                    scores.append(score)
                    valid_architectures.append(arch)
                    if score < self.best_score:
                        self.best_score = score
                        self.best_architecture = deepcopy(arch)
            if not valid_architectures:
                population = []
                while len(population) < self.population_size:
                    try:
                        arch = self.random_generate()
                        population.append(arch)
                    except Exception as e:
                        # print(f"Error regenerating architecture: {e}")
                        continue
                continue
            population = [x for _, x in sorted(zip(scores, valid_architectures))]
            population = population[:self.population_size//2]
            # mutate and generate new population
            new_population = []
            while len(new_population) < self.population_size:
                parent = random.choice(population)
                child = self.mutate(parent)
                new_population.append(child)
            population = new_population
            print(f"Generation {generation+1}/{self.num_generations}, "
                      f"Best architecture: {self.best_architecture}"
                      f"Best Score: {self.best_score:.4f}, "
                      f"Mean Score: {np.mean(scores):.4f}")
        print("Search completed.")
        print(f"Best architecture: {self.best_architecture}")
        return self.best_architecture