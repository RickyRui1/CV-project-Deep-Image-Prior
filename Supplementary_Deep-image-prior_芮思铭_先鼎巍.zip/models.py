import torch
import torch.nn as nn
import torch.nn.functional as F
"""
UNet start
"""
class UNet(nn.Module):
    """
    several encoders followed by several decoders (convs and transconvs)
    meanwhile there are skip connections in between    
    """
    def __init__(self, in_channels=3, out_channels=3, features=[64, 128, 256, 512]):
        super(UNet, self).__init__()
        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        # conv(down)
        for feature in features:
            self.downs.append(DoubleConv(in_channels, feature))
            in_channels = feature

        # transpose_conv(up)
        for feature in reversed(features):
            self.ups.append(nn.ConvTranspose2d(feature*2, feature, kernel_size=2, stride=2,))
            self.ups.append(DoubleConv(feature*2, feature))

        self.bottleneck = DoubleConv(features[-1], features[-1]*2)
        self.final_conv = nn.Conv2d(features[0], out_channels, kernel_size=1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        skip_connections = []

        # encoders
        for down in self.downs:
            x = down(x)
            # save skip connection
            skip_connections.append(x)
            x = self.pool(x)

        x = self.bottleneck(x)
        skip_connections = skip_connections[::-1]

        # decoders
        for idx in range(0, len(self.ups), 2):
            x = self.ups[idx](x)
            skip_connection = skip_connections[idx//2]

            # make sure the shape match
            if x.shape != skip_connection.shape:
                x = F.interpolate(x, size=skip_connection.shape[2:], mode='bilinear', align_corners=True)

            # add skip connection
            concat_skip = torch.cat((skip_connection, x), dim=1)
            x = self.ups[idx+1](concat_skip)

        return self.sigmoid(self.final_conv(x))

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DoubleConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)

"""
UNet end
"""

"""
SkipModel start
"""
class SkipModel(nn.Module):
    """
    The usage of this model is nearly identical to the skipnet in 
    the original paper, i.e. a more flexible UNet.
    """
    def __init__(self, in_channels=2, out_channels=3,
                 channels_down=[128]*5,
                 channels_up=[128]*5,
                 channels_skip=[4]*5,
                 upsample_mode='nearest'):
        super(SkipModel, self).__init__()
        self.encoders = nn.ModuleList()
        self.decoders = nn.ModuleList()
        self.skips = nn.ModuleList()
        self.upsamplers = nn.ModuleList()
        input_depth = in_channels
        
        for i in range(len(channels_down)):
            # skip connection
            if channels_skip[i] != 0:
                self.skips.append(nn.Sequential(
                    nn.Conv2d(input_depth, channels_skip[i], 1, bias=True),
                    nn.BatchNorm2d(channels_skip[i]),
                    nn.LeakyReLU(inplace=True)
                ))
            else:
                self.skips.append(nn.Identity())
                
            # encoders (down)
            encoder = nn.Sequential(
                nn.Conv2d(input_depth, channels_down[i], 3, stride=2, padding=1),
                nn.BatchNorm2d(channels_down[i]),
                nn.LeakyReLU(inplace=True),
                nn.Conv2d(channels_down[i], channels_down[i], 3, padding=1),
                nn.BatchNorm2d(channels_down[i]),
                nn.LeakyReLU(inplace=True)
            )
            self.encoders.append(encoder)
            
            # upsampler, can modify the upsample method here (eg. denoising)
            self.upsamplers.append(nn.Upsample(scale_factor=2, mode=upsample_mode))
            
            # decoders (up)
            in_channels = channels_skip[i] + channels_down[i]
            self.decoders.append(nn.Sequential(
                nn.Conv2d(in_channels, channels_up[i], 3, padding=1),
                nn.BatchNorm2d(channels_up[i]),
                nn.LeakyReLU(inplace=True)
            ))
            
            input_depth = channels_down[i]
        
        self.final_conv = nn.Conv2d(channels_up[0], out_channels, 1)
        # perform sigmoid to make sure the pixels are reasonable
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, x):
        skip_connections = []
        
        # encoder path with skip connections
        for i in range(len(self.encoders)):
            skip = self.skips[i](x)
            skip_connections.append(skip)
            x = self.encoders[i](x)
        
        # decoder path
        for i in range(len(self.decoders)-1, -1, -1):
            x = self.upsamplers[i](x)
            skip = skip_connections[i]
            if x.shape[2:] != skip.shape[2:]:
                x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=True)
            x = torch.cat([skip, x], dim=1)
            x = self.decoders[i](x)
        
        x = self.final_conv(x)
        return self.sigmoid(x)

"""
SkipModel end
"""