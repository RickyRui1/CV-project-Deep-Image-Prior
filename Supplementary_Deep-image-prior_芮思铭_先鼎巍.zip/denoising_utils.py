import os
from skimage.metrics import structural_similarity as ssim
from skimage import img_as_float
from skimage.color import rgb2gray
from skimage.restoration import estimate_sigma
import matplotlib.pyplot as plt
import numpy as np
import cv2
def save_image_grid(images_np, save_path, nrow=8):
    """Save several images_np in a grid to save_path in nrow s."""
    n_channels = max(x.shape[0] for x in images_np)
    images_np = [x if (x.shape[0] == n_channels) else np.concatenate([x, x, x], axis=0) for x in images_np]
    n_images = len(images_np)
    ncol = int(np.ceil(n_images / nrow)) 
    h, w = images_np[0].shape[1], images_np[0].shape[2]
    n_channels = images_np[0].shape[0]
    grid = np.zeros((n_channels, h * nrow, w * ncol))
    for idx, image in enumerate(images_np):
        i = idx // ncol 
        j = idx % ncol  
        grid[:, i*h:(i+1)*h, j*w:(j+1)*w] = image
    if images_np[0].shape[0] == 1:
        grid_to_save = grid[0] 
        plt.imsave(save_path, grid_to_save, cmap='gray', format='png')
    else:
        grid_to_save = grid.transpose(1, 2, 0) 
        plt.imsave(save_path, grid_to_save, format='png')    
    print(f"Image grid saved to: {save_path}")

def plot_frequency_spectrums(images, titles, nrow=4):
    """
    绘制一系列图片的频谱图。

    Args:
        images: list of np.array，每个元素是图片数据。
        titles: list of str，每个图片的标题。
        nrow: int，每行显示的图片数量。
    """
    # 检查输入是否匹配
    assert len(images) == len(titles), "图片数量和标题数量不匹配"

    n_images = len(images)
    ncol = int(np.ceil(n_images / nrow))  # 计算需要的列数

    plt.figure(figsize=(nrow * 4, ncol * 4))  # 动态调整画布大小

    for i, (img, title) in enumerate(zip(images, titles)):
        # 如果是 CHW 格式，将其转换为 HWC 格式
        if len(img.shape) == 3 and img.shape[0] in [3, 4]:  # CHW 格式
            img = np.transpose(img, (1, 2, 0))  # 转为 HWC 格式

        # 如果是 HWC 格式，将其转为灰度图
        if len(img.shape) == 3 and img.shape[-1] in [3, 4]:  # HWC 格式
            img = np.dot(img[..., :3], [0.2989, 0.5870, 0.1140])  # 转为灰度

        # 确保最终为二维灰度图
        if len(img.shape) != 2:
            raise ValueError(f"Image at index {i} is not a valid 2D grayscale image after processing.")
        # 计算频谱图
        f = np.fft.fft2(img)
        fshift = np.fft.fftshift(f)
        magnitude_spectrum = 20 * np.log(np.abs(fshift) + 1)

        # 在子图中绘制
        plt.subplot(ncol, nrow, i + 1)
        plt.imshow(magnitude_spectrum, cmap='gray')
        plt.title(title)
        plt.axis('off')

    plt.tight_layout()
    plt.show()

def save_frequency_spectrums(images, titles, save_path, nrow=4):
    """
    保存一系列图片的频谱图到文件。

    Args:
        images: list of np.array，每个元素是图片数据。
        titles: list of str，每个图片的标题。
        save_path: str，保存的图像路径。
        nrow: int，每行显示的图片数量。
    """
    # 检查输入是否匹配
    assert len(images) == len(titles), "图片数量和标题数量不匹配"

    n_images = len(images)
    ncol = int(np.ceil(n_images / nrow))  # 计算需要的列数

    plt.figure(figsize=(nrow * 4, ncol * 4))  # 动态调整画布大小

    for i, (img, title) in enumerate(zip(images, titles)):
        # 如果是 CHW 格式，将其转换为 HWC 格式
        if len(img.shape) == 3 and img.shape[0] in [3, 4]:  # CHW 格式
            img = np.transpose(img, (1, 2, 0))  # 转为 HWC 格式

        # 如果是 HWC 格式，将其转为灰度图
        if len(img.shape) == 3 and img.shape[-1] in [3, 4]:  # HWC 格式
            img = np.dot(img[..., :3], [0.2989, 0.5870, 0.1140])  # 转为灰度

        # 确保最终为二维灰度图
        if len(img.shape) != 2:
            raise ValueError(f"Image at index {i} is not a valid 2D grayscale image after processing.")
        # 计算频谱图
        f = np.fft.fft2(img)
        fshift = np.fft.fftshift(f)
        magnitude_spectrum = 20 * np.log(np.abs(fshift) + 1)

        # 在子图中绘制
        plt.subplot(ncol, nrow, i + 1)
        plt.imshow(magnitude_spectrum, cmap='gray')
        plt.title(title)
        plt.axis('off')

    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def calculate_niqe(image):
    """
    计算图像的 NIQE 值。

    Args:
        image: np.array，输入图像（支持 RGB 或灰度图像）。

    Returns:
        niqe_score: float，图像的 NIQE 值，值越低质量越好。
    """
    if len(image.shape) == 3 and image.shape[-1] == 3:
        # 转换为灰度图像
        image = rgb2gray(image)
    
    # 转换为浮点型
    image = img_as_float(image)
    
    # 计算图像的局部均值和方差
    mu = cv2.GaussianBlur(image, (7, 7), 1.166)  # 高斯平滑
    sigma = np.sqrt(np.abs(image - mu))  # 局部标准差

    # 提取局部特征
    features = np.stack([mu.ravel(), sigma.ravel()], axis=1)

    # 计算均值和协方差矩阵
    mu_features = np.mean(features, axis=0)
    cov_features = np.cov(features, rowvar=False)

    # 预设的自然场景统计（NSS）模型
    mu_nss = np.array([0.5, 0.5])
    cov_nss = np.array([[0.3, 0.0], [0.0, 0.3]])

    # 计算马氏距离 (Mahalanobis distance)
    diff = mu_features - mu_nss
    inv_cov_nss = np.linalg.inv(cov_nss)
    niqe_score = np.sqrt(diff.T @ inv_cov_nss @ diff)

    return niqe_score

